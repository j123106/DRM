import subprocess
import sys

def install_requirements():
    try:
        # Check if pip is installed
        subprocess.check_call([sys.executable, '-m', 'pip', '--version'])

        # Install dependencies from requirements.txt
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])

        print("All dependencies have been installed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while installing dependencies: {e}")

if __name__ == "__main__":
    install_requirements()

import os
from tkinter import *
from tkinter import filedialog, messagebox
from tkinter import ttk
from cryptography.fernet import Fernet

# Function to decrypt the selected file using the provided key
def decrypt_file():
    key = key_entry.get()  # Get the key from the input box
    try:
        fernet = Fernet(key.encode())  # Ensure the key is in bytes
    except Exception as e:
        messagebox.showerror("Error", f"Invalid key format: {str(e)}")
        return

    # Open a file dialog to select the file to decrypt
    file_path = filedialog.askopenfilename(filetypes=[("Encrypted files", "*.codibu")])

    if not file_path:
        return

    # Read the encrypted file data
    with open(file_path, "rb") as file:
        encrypted_data = file.read()

    try:
        # Decrypt the file data
        decrypted_data = fernet.decrypt(encrypted_data)

        # Save the decrypted file
        with open(file_path.replace(".codibu", ""), "wb") as file:
            file.write(decrypted_data)

        messagebox.showinfo("Success", "File decrypted and saved as " + file_path.replace(".codibu", ""))
    except:
        messagebox.showerror("Error", "Decryption failed. Invalid key or file.")


# Function to make the window draggable
def make_window_draggable(window):
    def start_move(event):
        window.x = event.x
        window.y = event.y

    def stop_move(event):
        window.x = None
        window.y = None

    def on_motion(event):
        x, y = event.x - window.x, event.y - window.y
        window.geometry(f"+{window.winfo_x() + x}+{window.winfo_y() + y}")

    window.bind("<Button-1>", start_move)
    window.bind("<ButtonRelease-1>", stop_move)
    window.bind("<B1-Motion>", on_motion)


# Create a more polished GUI window with Codibu branding
def create_gui():
    window = Tk()
    window.title("Codibu - Secure Decryption Tool")

    # Set window size and background color
    window.geometry("600x500")
    window.configure(bg="#f9f9f9")  # Light modern background color

    # Remove title bar
    window.overrideredirect(1)

    # Calculate center position
    window.update_idletasks()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    window_width = 600
    window_height = 500

    x = (screen_width // 2) - (window_width // 2)
    y = (screen_height // 2) - (window_height // 2)

    # Set the window position to the center of the screen
    window.geometry(f'{window_width}x{window_height}+{x}+{y}')

    # Add padding to the main layout
    window.grid_rowconfigure(0, weight=1)
    window.grid_columnconfigure(0, weight=1)

    # Add a frame for better layout management
    main_frame = Frame(window, bg="#ffffff", padx=40, pady=40, relief=RAISED, bd=2)
    main_frame.pack(expand=True, fill=BOTH, padx=20, pady=20)

    # Close button (top-right corner)
    close_button = Button(main_frame, text="X", command=window.destroy, bg="#e74c3c", fg="white",
                          font=("Arial", 7, "bold"), bd=0, padx=10, pady=5, cursor="hand2", relief=FLAT)
    close_button.place(x=3, y=-3)

    # Add a logo or title
    logo_label = Label(main_frame, text="CODIBU", font=("Helvetica", 28, "bold"), fg="#2c3e50", bg="#ffffff")
    logo_label.pack(pady=10)

    # Create a header section with company branding
    header_label = Label(main_frame, text="Secure Decryption Tool", font=("Helvetica", 18, "bold"), bg="#ffffff", fg="#27ae60")
    header_label.pack(pady=5)

    # Divider line
    divider = Frame(main_frame, height=2, bd=1, relief=SUNKEN, bg="#27ae60")
    divider.pack(fill="x", pady=10)

    # Instruction Label
    instruction_label = Label(main_frame, text="Enter your secret key to decrypt the file:", font=("Arial", 14), bg="#ffffff", fg="#555555")
    instruction_label.pack(pady=10)

    # Secret key entry box
    global key_entry
    key_entry = Entry(main_frame, show="*", width=40, font=("Arial", 14), relief=SOLID, bd=2)
    key_entry.pack(pady=10)

    # Decrypt button with improved styling
    decrypt_button = Button(main_frame, text="Decrypt File", command=decrypt_file, bg="#27ae60", fg="white",
                            font=("Arial", 14, "bold"), bd=0, padx=20, pady=10, cursor="hand2", relief=RAISED)
    decrypt_button.pack(pady=20)

    # Footer with company branding or info
    footer_label = Label(main_frame, text="© 2024 CODIBU. All rights reserved.", font=("Helvetica", 10), bg="#ffffff", fg="#888888")
    footer_label.pack(pady=15)

    # Make the window draggable
    make_window_draggable(window)

    window.mainloop()


if __name__ == "__main__":
    create_gui()
